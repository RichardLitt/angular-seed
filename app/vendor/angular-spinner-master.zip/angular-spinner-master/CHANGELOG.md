# Changelog

## 0.2.1 - 2013-08-28

- Add test coverage reporting
- Stop the spinner on scope destroy
- Support for AngularJS 1.2
